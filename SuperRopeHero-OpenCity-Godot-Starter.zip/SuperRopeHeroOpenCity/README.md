# Super Rope Hero: Open City — Godot starter

An original, asset-free starter project for a mobile 3D superhero sandbox. It is **not** a complete commercial game and does not copy Rope Hero: Vice Town's code, characters, art, or branding.

## What's included
- Procedurally generated block city with collision and rooftops
- Third-person capsule hero, movement, jump, and follow camera
- Prototype raycast grappling line and pull force
- Touchscreen movement/action buttons plus keyboard controls for testing
- A simple green-marker mission objective

## Open on an Android phone
1. Install the official Godot Android editor from https://godotengine.org/download/android/ .
2. Extract this ZIP into a folder on your phone (for example `Documents/SuperRopeHeroOpenCity`).
3. In Godot Android editor, import/open the folder containing `project.godot`.
4. Open the project and press Play. If your editor version asks to upgrade the project, make a copy first.

## Build an APK
Godot's Android editor may not support every export step on every device. For a release APK, configure Android export templates and the Android SDK/JDK as described in the official docs: https://docs.godotengine.org/en/stable/tutorials/export/exporting_for_android.html . A desktop computer or cloud build environment may be needed.

## Controls
- Desktop testing: WASD or arrow keys to move, Space to jump, F to grapple, G to release.
- Touch: on-screen movement, JUMP, ROPE, and DROP buttons.

## Known prototype limitations
- Rope is a simple raycast-and-pull prototype, not a polished physics rope.
- No car driving, combat, pedestrians, save system, audio, or finished mission campaign yet.
- City is generated from primitive shapes; replace with optimized art assets before a larger game.
- Performance will vary by phone. This starter intentionally uses Godot's Compatibility renderer.
