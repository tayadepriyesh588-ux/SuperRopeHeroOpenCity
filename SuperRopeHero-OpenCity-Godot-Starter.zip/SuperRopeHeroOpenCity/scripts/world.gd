extends Node3D

# Generates a lightweight procedural city so the project runs without external assets.
var hero: CharacterBody3D
var status_label: Label
var mission_marker: MeshInstance3D
var mission_done := false

func _ready() -> void:
	_make_environment()
	_make_city()
	_make_hero()
	_make_mission()

func _make_environment() -> void:
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-52, -28, 0)
	sun.light_energy = 1.2
	add_child(sun)
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.sky.sky_material = ProceduralSkyMaterial.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.88)
	env.ambient_light_energy = 0.7
	world_env.environment = env
	add_child(world_env)

func _mat(color: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	return m

func _box(parent: Node3D, size: Vector3, pos: Vector3, material: Material, collision := true) -> MeshInstance3D:
	var body: StaticBody3D
	if collision:
		body = StaticBody3D.new()
		body.position = pos
		parent.add_child(body)
	var mesh := BoxMesh.new()
	mesh.size = size
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	if collision:
		body.add_child(instance)
		var shape := CollisionShape3D.new()
		var box_shape := BoxShape3D.new()
		box_shape.size = size
		shape.shape = box_shape
		body.add_child(shape)
	else:
		instance.position = pos
		parent.add_child(instance)
	return instance

func _make_city() -> void:
	_box(self, Vector3(180, 1, 180), Vector3(0, -0.6, 0), _mat(Color(0.23, 0.48, 0.25)))
	# Two broad roads crossing the city.
	_box(self, Vector3(180, 0.12, 12), Vector3(0, -0.02, 0), _mat(Color(0.12, 0.13, 0.15)), false)
	_box(self, Vector3(12, 0.13, 180), Vector3(0, 0.0, 0), _mat(Color(0.12, 0.13, 0.15)), false)
	var palette := [Color(0.68,0.71,0.77), Color(0.78,0.65,0.52), Color(0.48,0.58,0.69), Color(0.75,0.74,0.66), Color(0.53,0.62,0.58)]
	var rng := RandomNumberGenerator.new()
	rng.seed = 72931
	for x in range(-4, 5):
		for z in range(-4, 5):
			if abs(x) <= 1 or abs(z) <= 1:
				continue
			var h := rng.randf_range(7.0, 22.0)
			var w := rng.randf_range(7.0, 11.0)
			var d := rng.randf_range(7.0, 11.0)
			var p := Vector3(x * 18.0 + rng.randf_range(-2,2), h/2.0, z * 18.0 + rng.randf_range(-2,2))
			_box(self, Vector3(w,h,d), p, _mat(palette[rng.randi_range(0,palette.size()-1)]))
			# Flat rooftop lip makes buildings easier to read from a distance.
			_box(self, Vector3(w+0.25,0.25,d+0.25), p + Vector3(0,h/2.0,0), _mat(Color(0.28,0.31,0.36)), false)

func _make_hero() -> void:
	hero = CharacterBody3D.new()
	hero.name = "Hero"
	hero.position = Vector3(0, 2, 8)
	hero.set_script(load("res://scripts/hero_controller.gd"))
	add_child(hero)
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.48
	capsule.height = 1.9
	var body_mesh := MeshInstance3D.new()
	body_mesh.name = "HeroMesh"
	body_mesh.mesh = capsule
	body_mesh.material_override = _mat(Color(0.06, 0.28, 0.86))
	body_mesh.position.y = 0.95
	hero.add_child(body_mesh)
	var shape := CollisionShape3D.new()
	var capsule_shape := CapsuleShape3D.new()
	capsule_shape.radius = 0.48
	capsule_shape.height = 1.9
	shape.shape = capsule_shape
	shape.position.y = 0.95
	hero.add_child(shape)
	var camera_pivot := Node3D.new()
	camera_pivot.name = "CameraPivot"
	camera_pivot.position = Vector3(0, 1.45, 0)
	hero.add_child(camera_pivot)
	var camera := Camera3D.new()
	camera.name = "Camera3D"
	camera.position = Vector3(0, 3.0, 7.0)
	camera.rotation_degrees.x = -16
	camera.current = true
	camera_pivot.add_child(camera)

func _make_mission() -> void:
	mission_marker = MeshInstance3D.new()
	var mesh := CylinderMesh.new()
	mesh.top_radius = 1.8
	mesh.bottom_radius = 1.8
	mesh.height = 0.18
	mission_marker.mesh = mesh
	mission_marker.material_override = _mat(Color(0.1, 0.95, 0.5, 0.8))
	mission_marker.position = Vector3(25, 0.2, -25)
	add_child(mission_marker)
	var label := Label.new()
	label.text = "MISSION 01: Reach the green marker"
	label.add_theme_font_size_override("font_size", 24)
	label.position = Vector2(20, 18)
	# HUD script owns the actual screen label; this node is only the world marker.

func update_mission(hero_position: Vector3) -> String:
	if not mission_done and hero_position.distance_to(mission_marker.position) < 3.0:
		mission_done = true
		mission_marker.visible = false
		return "MISSION COMPLETE! Explore the city."
	return "MISSION 01: Reach the green marker" if not mission_done else "MISSION COMPLETE — explore the city"
