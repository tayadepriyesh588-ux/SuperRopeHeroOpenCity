extends CanvasLayer

var mission_label: Label
var help_label: Label
var hero: CharacterBody3D
var held_move := Vector2.ZERO

func _ready() -> void:
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	mission_label = Label.new()
	mission_label.position = Vector2(22, 18)
	mission_label.add_theme_font_size_override("font_size", 22)
	mission_label.add_theme_color_override("font_color", Color.WHITE)
	mission_label.add_theme_color_override("font_shadow_color", Color.BLACK)
	mission_label.add_theme_constant_override("shadow_offset_x", 2)
	mission_label.add_theme_constant_override("shadow_offset_y", 2)
	mission_label.text = "MISSION 01: Reach the green marker"
	root.add_child(mission_label)
	help_label = Label.new()
	help_label.position = Vector2(22, 50)
	help_label.add_theme_font_size_override("font_size", 16)
	help_label.text = "WASD / arrows: move • Space: jump • F: grapple • G: release"
	root.add_child(help_label)
	_add_button(root, "◀", Vector2(32, -120), Vector2(72,72), "left")
	_add_button(root, "▶", Vector2(190, -120), Vector2(72,72), "right")
	_add_button(root, "▲", Vector2(111, -200), Vector2(72,72), "forward")
	_add_button(root, "▼", Vector2(111, -120), Vector2(72,72), "back")
	_add_button(root, "JUMP", Vector2(-270, -115), Vector2(100,70), "jump")
	_add_button(root, "ROPE", Vector2(-165, -195), Vector2(100,70), "grapple")
	_add_button(root, "DROP", Vector2(-165, -115), Vector2(100,70), "release")
	call_deferred("_find_hero")

func _find_hero() -> void:
	var root_node := get_parent()
	hero = root_node.get_node_or_null("Hero")

func _add_button(parent: Control, title: String, offset: Vector2, size: Vector2, action: String) -> void:
	var b := Button.new()
	b.text = title
	b.size = size
	b.anchor_left = 0.0 if offset.x >= 0 else 1.0
	b.anchor_right = b.anchor_left
	b.anchor_top = 1.0
	b.anchor_bottom = 1.0
	b.position = offset
	b.modulate = Color(1,1,1,0.82)
	b.add_theme_font_size_override("font_size", 20)
	parent.add_child(b)
	if action in ["left", "right", "forward", "back"]:
		b.button_down.connect(func(): _set_move(action, true))
		b.button_up.connect(func(): _set_move(action, false))
	else:
		b.pressed.connect(func(): _press_action(action))

func _set_move(action: String, down: bool) -> void:
	if hero == null:
		_find_hero()
	if hero == null: return
	var v: Vector2 = hero.touch_move
	match action:
		"left": v.x = -1 if down else (0 if v.x < 0 else v.x)
		"right": v.x = 1 if down else (0 if v.x > 0 else v.x)
		"forward": v.y = -1 if down else (0 if v.y < 0 else v.y)
		"back": v.y = 1 if down else (0 if v.y > 0 else v.y)
	hero.touch_move = v

func _press_action(action: String) -> void:
	if hero == null: _find_hero()
	if hero == null: return
	match action:
		"jump": hero.touch_jump = true
		"grapple": hero.touch_grapple = true
		"release": hero.touch_release = true

func set_mission_text(value: String) -> void:
	if is_instance_valid(mission_label): mission_label.text = value
