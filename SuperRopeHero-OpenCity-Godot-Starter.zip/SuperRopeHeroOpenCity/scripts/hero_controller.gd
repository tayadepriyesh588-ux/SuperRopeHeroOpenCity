extends CharacterBody3D

@export var move_speed := 8.0
@export var jump_velocity := 9.0
@export var grapple_range := 48.0
@export var swing_pull := 18.0
var rope_anchor: Vector3
var rope_active := false
var rope_line: MeshInstance3D
var gravity: float = 24.0
var camera: Camera3D
var world_node: Node3D
var touch_move := Vector2.ZERO
var touch_jump := false
var touch_grapple := false
var touch_release := false

func _ready() -> void:
	camera = get_node("CameraPivot/Camera3D")
	world_node = get_parent()
	rope_line = MeshInstance3D.new()
	var line_mesh := ImmediateMesh.new()
	rope_line.mesh = line_mesh
	var line_mat := StandardMaterial3D.new()
	line_mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	line_mat.albedo_color = Color(1.0, 0.86, 0.2)
	rope_line.material_override = line_mat
	world_node.add_child(rope_line)

func _physics_process(delta: float) -> void:
	var input_vec := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	if touch_move.length() > 0.1:
		input_vec = touch_move
	var forward := -camera.global_basis.z
	var right := camera.global_basis.x
	forward.y = 0
	right.y = 0
	forward = forward.normalized()
	right = right.normalized()
	var direction := (right * input_vec.x + forward * -input_vec.y).normalized()
	if direction.length() > 0.01:
		velocity.x = direction.x * move_speed
		velocity.z = direction.z * move_speed
		look_at(global_position + direction, Vector3.UP)
	else:
		velocity.x = move_toward(velocity.x, 0, move_speed * 2.5 * delta)
		velocity.z = move_toward(velocity.z, 0, move_speed * 2.5 * delta)
	if not is_on_floor():
		velocity.y -= gravity * delta
	elif Input.is_action_just_pressed("jump") or touch_jump:
		velocity.y = jump_velocity
	touch_jump = false
	if Input.is_action_just_pressed("grapple") or touch_grapple:
		_try_grapple()
	touch_grapple = false
	if Input.is_action_just_pressed("release_rope") or touch_release:
		rope_active = false
	touch_release = false
	if rope_active:
		var to_anchor := rope_anchor - global_position
		velocity += to_anchor.normalized() * swing_pull * delta
		# Keep a little momentum when swinging; this is a prototype grapple, not a final rope simulation.
		if global_position.distance_to(rope_anchor) > grapple_range * 1.4:
			rope_active = false
	_update_rope()
	move_and_slide()
	if world_node.has_method("update_mission"):
		var text := world_node.update_mission(global_position)
		var hud := world_node.get_node_or_null("MobileHUD")
		if hud and hud.has_method("set_mission_text"):
			hud.set_mission_text(text)

func _try_grapple() -> void:
	var origin := camera.global_position
	var end := origin + -camera.global_basis.z * grapple_range
	var query := PhysicsRayQueryParameters3D.create(origin, end)
	query.exclude = [self]
	var hit := get_world_3d().direct_space_state.intersect_ray(query)
	if not hit.is_empty():
		rope_anchor = hit.position
		rope_active = true
		velocity.y += 2.0

func _update_rope() -> void:
	var im := rope_line.mesh as ImmediateMesh
	im.clear_surfaces()
	if not rope_active:
		return
	im.surface_begin(Mesh.PRIMITIVE_LINES)
	im.surface_add_vertex(rope_line.to_local(global_position + Vector3(0, 1.2, 0)))
	im.surface_add_vertex(rope_line.to_local(rope_anchor))
	im.surface_end()
